package com.appcode.annotations.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.text.Editable;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.appcode.annotations.R;

public class PasswordDialog extends DialogFragment implements View.OnClickListener {

    private boolean hidePassword = false;

    private TextInputEditText editText;

    private OnClickCancelListener onClickCancelListener;
    private OnClickConfirmListener onClickConfirmListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, 0);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_password, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        editText = view.findViewById(R.id.edit_text);

        if (hidePassword) {
            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }

        view.findViewById(R.id.btnCancel).setOnClickListener(this);
        view.findViewById(R.id.btnConfirm).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnCancel:
                if (onClickCancelListener != null) {
                    onClickCancelListener.onCancel();
                }
                dismiss();
                break;
            case R.id.btnConfirm:
                Editable editable = editText.getText();
                if (editable != null) {
                    String password = editable.toString().trim();

                    if (password.isEmpty() || password.length() < 2) {
                        editText.setError(getString(R.string.message_input_password_not_empty));
                        return;
                    }

                    if (onClickConfirmListener != null) {
                        onClickConfirmListener.onConfirm(password);
                    }

                    dismiss();
                }

                break;
        }
    }

    public void setHidePassword(boolean hidePassword) {
        this.hidePassword = hidePassword;
    }

    public void setOnClickConfirmListener(OnClickConfirmListener onClickConfirmListener) {
        this.onClickConfirmListener = onClickConfirmListener;
    }

    public void setOnClickCancelListener(OnClickCancelListener onClickCancelListener) {
        this.onClickCancelListener = onClickCancelListener;
    }

    public interface OnClickCancelListener {
        void onCancel();
    }

    public interface OnClickConfirmListener {
        void onConfirm(String password);
    }
}

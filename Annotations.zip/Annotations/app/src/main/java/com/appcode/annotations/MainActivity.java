package com.appcode.annotations;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.appcode.annotations.adapter.FolderNoteAdapter;
import com.appcode.annotations.dialog.BottomSheetMenuDialog;
import com.appcode.annotations.dialog.NewFolderDialog;
import com.appcode.annotations.model.Folder;
import com.appcode.annotations.model.Note;
import com.appcode.annotations.swipe.SwipeController;
import com.appcode.annotations.viewmodel.FolderViewModel;
import com.appcode.annotations.viewmodel.NoteViewModel;

import java.util.List;

public class MainActivity extends AppCompatActivity implements BottomSheetMenuDialog.OptionClickListener {

    private static final String TAG = "MainActivt";

    private boolean emptyFolders = false;
    private boolean emptyNotes = false;

    private TextView emptyTextView;

    private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private NoteViewModel noteViewModel;
    private FolderViewModel folderViewModel;

    private FolderNoteAdapter folderNoteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int xScreen = getResources().getDisplayMetrics().widthPixels;
        int item = getResources().getDimensionPixelSize(R.dimen.item_note_width);
        int spanCount = (xScreen / item);

        emptyTextView = findViewById(R.id.emptyTextView);
        emptyTextView.setVisibility(View.GONE);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, spanCount));

        SwipeController swipeController = new SwipeController();
        swipeController.setSwipeCallback(new SwipeController.SwipeCallback() {
            @Override
            public void onSwipe(int itemPosition) {
                callToDeleteItem(itemPosition);
            }
        });

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeController);
        itemTouchhelper.attachToRecyclerView(recyclerView);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(onClickFabButton());

        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);
        noteViewModel.getAllNotes().observe(this, new Observer<List<Note>>() {
            @Override
            public void onChanged(@Nullable List<Note> notes) {
                //  update recycler view
                if (recyclerView != null && notes != null) {

                    if (folderNoteAdapter == null) {
                        createAdapterFolderNote();
                        recyclerView.setAdapter(folderNoteAdapter);
                    }

                    folderNoteAdapter.setNotes(notes);
                }

                emptyNotes = (notes == null || notes.isEmpty());
                checkEmpty();
            }
        });

        folderViewModel = ViewModelProviders.of(this).get(FolderViewModel.class);
        folderViewModel.getAllFolders().observe(this, new Observer<List<Folder>>() {
            @Override
            public void onChanged(@Nullable List<Folder> folders) {
                //  update recycler view
                if (recyclerView != null && folders != null) {

                    if (folderNoteAdapter == null) {
                        createAdapterFolderNote();
                        recyclerView.setAdapter(folderNoteAdapter);
                    }

                    folderNoteAdapter.setFolders(folders);
                }

                emptyFolders = (folders == null || folders.isEmpty());
                checkEmpty();
            }
        });
    }

    private void checkEmpty() {
        emptyTextView.setVisibility((emptyFolders && emptyNotes) ? View.VISIBLE : View.GONE);
    }

    private void callToDeleteItem(final int position) {
        final Object ob = folderNoteAdapter.findItem(position);

        if (ob instanceof Note) {
            Snackbar.make(fab, R.string.question_delete_note, Snackbar.LENGTH_LONG)
                    .setAction(R.string.delete, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            noteViewModel.delete((Note) ob);
                        }
                    }).show();

        } else if (ob instanceof Folder) {
            Snackbar.make(fab, R.string.question_delete_folder, Snackbar.LENGTH_LONG)
                    .setAction(R.string.delete, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            folderViewModel.delete((Folder) ob);
                        }
                    }).show();
        }
    }

    private void createAdapterFolderNote() {
        folderNoteAdapter = new FolderNoteAdapter(MainActivity.this);

        //click folder
        folderNoteAdapter.setOnFolderClickListener(new FolderNoteAdapter.onFolderClickListener() {
            @Override
            public void onClickFolder(Folder folder) {
                Log.d(TAG, "onClickFolder: ");
            }
        });

        // click note
        folderNoteAdapter.setOnNoteClickListener(new FolderNoteAdapter.OnNoteClickListener() {
            @Override
            public void onClickNote(Note note) {
                Log.d(TAG, "onClickNote: ");
                startActivityForResult(NewNoteActivity.buildUpdateIntent(MainActivity.this, note), 0);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if ((resultCode == NewNoteActivity.RESULT_CREATE || resultCode == NewNoteActivity.RESULT_UPDATE) && data != null) {
            Note note = data.getParcelableExtra(NewNoteActivity.NOTE_INTENT_KEY);
            if (note != null) {

                switch (resultCode) {
                    case NewNoteActivity.RESULT_CREATE:
                        noteViewModel.insert(note);
                        break;
                    case NewNoteActivity.RESULT_UPDATE:
                        Toast.makeText(this, "Result File", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "onActivityResult: " + note.getMessage());
                        noteViewModel.update(note);
                        break;
                }

            }
        }
    }

    private View.OnClickListener onClickFabButton() {
        return new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                BottomSheetMenuDialog bottomSheetMenuDialog = new BottomSheetMenuDialog();
                bottomSheetMenuDialog.show(getSupportFragmentManager(), bottomSheetMenuDialog.getTag());
                bottomSheetMenuDialog.setOptionClickListener(MainActivity.this);
            }
        };
    }

    @Override
    public void onClickFolder() {
        NewFolderDialog newFolderDialog = new NewFolderDialog();
        newFolderDialog.show(getSupportFragmentManager(), newFolderDialog.getTag());
        newFolderDialog.setOnClickConfirmListener(new NewFolderDialog.OnClickConfirmListener() {
            @Override
            public void onClick(Folder folder) {
                folderViewModel.insert(folder);
            }
        });
    }

    @Override
    public void onClickFile() {
        new MaterialDialog.Builder(this)
                .iconRes(R.drawable.ic_file_text)
                .title(R.string.new_note)
                .titleColorRes(R.color.green_color)
                .inputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                .inputRange(3, 25)
                .input(R.string.title, R.string.hint_fill, new MaterialDialog.InputCallback() {
                    @Override
                    public void onInput(@NonNull MaterialDialog dialog, CharSequence input) {

                        Note note = new Note();
                        note.setTitle(input.toString());
                        noteViewModel.insert(note);

                        startActivityForResult(NewNoteActivity.buildUpdateIntent(MainActivity.this, note), 0);
                    }
                })
                .positiveText(R.string.confirm)
                .show();
    }
}

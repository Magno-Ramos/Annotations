package com.appcode.annotations.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.appcode.annotations.R;
import com.appcode.annotations.model.Folder;
import com.appcode.annotations.model.Note;
import com.appcode.annotations.model.TagType;

import java.util.List;

public class FolderNoteAdapter extends RecyclerView.Adapter<FolderNoteAdapter.NoteViewHolder> {

    private static final int NOTE_TYPE = 1;
    private static final int FOLDER_TYPE = 2;

    private Context context;
    private List<Note> notes;
    private List<Folder> folders;

    private OnNoteClickListener onNoteClickListener;
    private onFolderClickListener onFolderClickListener;

    public FolderNoteAdapter(@NonNull Context context) {
        this.context = context;
    }

    public void setFolders(List<Folder> folders) {
        this.folders = folders;
        notifyDataSetChanged();
    }

    public void setNotes(List<Note> notes) {
        this.notes = notes;
        notifyDataSetChanged();
    }

    public void setOnNoteClickListener(OnNoteClickListener onNoteClickListener) {
        this.onNoteClickListener = onNoteClickListener;
    }

    public void setOnFolderClickListener(FolderNoteAdapter.onFolderClickListener onFolderClickListener) {
        this.onFolderClickListener = onFolderClickListener;
    }

    @NonNull
    @Override
    public FolderNoteAdapter.NoteViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_annotation, viewGroup, false);
        return new FolderNoteAdapter.NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FolderNoteAdapter.NoteViewHolder noteViewHolder, int position) {

        int viewType = getItemViewType(position);
        if (viewType == FOLDER_TYPE) {

            // setup file
            final Folder folder = folders.get(position);

            noteViewHolder.imageView.setImageResource(R.drawable.ic_folder);
            noteViewHolder.textView.setText(folder.getTitle());

            noteViewHolder.item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onFolderClickListener != null) {
                        onFolderClickListener.onClickFolder(folder);
                    }
                }
            });

            setImageViewLock(noteViewHolder.imageViewLock, folder.isLocked());
            setImageViewTagType(noteViewHolder.imageViewTag, folder.getTag());

        } else {

            // setup folder
            position = position - ((folders != null) ? folders.size() : 0);
            final Note note = notes.get(position);

            noteViewHolder.imageView.setImageResource(R.drawable.ic_description);
            noteViewHolder.textView.setText(note.getTitle());

            noteViewHolder.item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onNoteClickListener != null) {
                        onNoteClickListener.onClickNote(note);
                    }
                }
            });

            setImageViewLock(noteViewHolder.imageViewLock, note.isLocked());
            setImageViewTagType(noteViewHolder.imageViewTag, note.getTag());
        }
    }

    private void setImageViewLock(ImageView imageView, boolean locked) {
        imageView.setImageResource(locked ? R.drawable.ic_lock : R.drawable.ic_unlock);
    }

    private void setImageViewTagType(ImageView imageView, TagType tagType) {
        switch (tagType) {
            case RED:
                imageView.setImageResource(R.drawable.ic_tag_red);
                break;
            default:
                imageView.setImageResource(R.drawable.ic_tag_white);
        }
    }

    @Override
    public int getItemCount() {
        int count = 0;
        if (folders != null) {
            count = folders.size();
        }

        if (notes != null) {
            count += notes.size();
        }
        return count;
    }

    @Override
    public int getItemViewType(int position) {
        if (folders != null) {
            return ((position + 1 > folders.size()) ? NOTE_TYPE : FOLDER_TYPE);
        } else {
            return NOTE_TYPE;
        }
    }

    public Object findItem(int position) {
        if (getItemViewType(position) == FOLDER_TYPE) {
            return folders.get(position);
        } else {
            return notes.get(position - (folders.size()));
        }
    }

    class NoteViewHolder extends RecyclerView.ViewHolder {
        View item;
        ImageView imageView;
        ImageView imageViewTag;
        ImageView imageViewLock;
        TextView textView;

        NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            imageView = itemView.findViewById(R.id.imageView);
            imageViewLock = itemView.findViewById(R.id.image_view_lock);
            imageViewTag = itemView.findViewById(R.id.image_view_tag);
            item = itemView.findViewById(R.id.itemView);
        }
    }

    public interface OnNoteClickListener {
        void onClickNote(Note note);
    }

    public interface onFolderClickListener {
        void onClickFolder(Folder folder);
    }
}

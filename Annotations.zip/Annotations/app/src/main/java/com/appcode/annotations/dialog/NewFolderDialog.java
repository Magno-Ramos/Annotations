package com.appcode.annotations.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.appcode.annotations.R;
import com.appcode.annotations.model.Folder;

public class NewFolderDialog extends DialogFragment implements View.OnClickListener {

    private OnClickCancelListener onClickCancelListener;
    private OnClickConfirmListener onClickConfirmListener;

    private TextInputEditText editText;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, 0);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_new_folder, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        editText = view.findViewById(R.id.edt_folder_name);

        // buttons
        view.findViewById(R.id.btnConfirm).setOnClickListener(this);
        view.findViewById(R.id.btnCancel).setOnClickListener(this);
    }

    private boolean validateFolderName(String folderName) {
        if (folderName.trim().isEmpty()){
            editText.setError( "O Nome não pode ser vazio" );
            return false;
        }

        if (folderName.trim().length() < 2){
            editText.setError( "Coloque um nome um pouco maior" );
            return false;
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnConfirm:

                String folderName = editText.getText().toString().trim();
                if (  validateFolderName(folderName) && onClickConfirmListener != null) {

                    Folder folder = new Folder();
                    folder.setTitle(folderName);
                    onClickConfirmListener.onClick(folder);

                    dismiss();
                }

                break;
            case R.id.btnCancel:
                dismiss();

                if (onClickCancelListener != null) {
                    onClickCancelListener.onClick();
                }
                break;
        }
    }

    public void setOnClickCancelListener(OnClickCancelListener onClickCancelListener) {
        this.onClickCancelListener = onClickCancelListener;
    }

    public void setOnClickConfirmListener(OnClickConfirmListener onClickConfirmListener) {
        this.onClickConfirmListener = onClickConfirmListener;
    }

    public interface OnClickCancelListener {
        void onClick();
    }

    public interface OnClickConfirmListener {
        void onClick(Folder folder);
    }
}

package com.appcode.annotations.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.appcode.annotations.R;

public class BottomSheetMenuDialog extends BottomSheetDialogFragment implements View.OnClickListener {

    private OptionClickListener optionClickListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_menu_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        view.findViewById(R.id.btFile).setOnClickListener(this);
        view.findViewById(R.id.btFolder).setOnClickListener(this);
    }

    public void setOptionClickListener(OptionClickListener optionClickListener) {
        this.optionClickListener = optionClickListener;
    }

    @Override
    public void onClick(View v) {
        dismiss();

        if (optionClickListener != null) {
            switch (v.getId()) {
                case R.id.btFile:
                    optionClickListener.onClickFile();
                    break;
                case R.id.btFolder:
                    optionClickListener.onClickFolder();
                    break;
            }
        }
    }

    public interface OptionClickListener {
        void onClickFolder();

        void onClickFile();
    }
}

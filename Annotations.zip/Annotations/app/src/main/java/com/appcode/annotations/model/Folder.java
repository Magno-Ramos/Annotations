package com.appcode.annotations.model;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.TypeConverters;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "folder_table")
@TypeConverters({NoteTypeConverter.class, TagTypeConverter.class})
public class Folder extends Item {

    private List<Note> notes;

    public Folder() {
        super();
        this.notes = new ArrayList<>();
    }

    public List<Note> getNotes() {
        return notes;
    }

    public void setNotes(List<Note> notes) {
        this.notes = notes;
    }
}

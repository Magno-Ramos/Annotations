package com.appcode.annotations.database;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

import com.appcode.annotations.dao.FolderDao;
import com.appcode.annotations.dao.NoteDao;
import com.appcode.annotations.model.Folder;
import com.appcode.annotations.model.Note;
import com.appcode.annotations.model.TagType;

@Database(entities = {Note.class, Folder.class}, version = 1, exportSchema = false)
public abstract class NoteDatabase extends RoomDatabase {

    private static NoteDatabase instance;

    public abstract NoteDao noteDao();

    public abstract FolderDao folderDao();

    public static synchronized NoteDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(), NoteDatabase.class, "note_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new WelcomeNoteTask(instance).execute();
        }
    };

    private static class WelcomeNoteTask extends AsyncTask<Void, Void, Void> {

        private NoteDao noteDao;

        WelcomeNoteTask(NoteDatabase noteDatabase){
            this.noteDao = noteDatabase.noteDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            Note note = new Note();
            note.setTitle("Bem vindo !");
            note.setMessage("Seja bem ao nosso aplicativo. \n\nSalve suas anotações e se organize facilmente :D");
            note.setTag(TagType.GREEN);

            noteDao.insert( note );
            return null;
        }
    }
}

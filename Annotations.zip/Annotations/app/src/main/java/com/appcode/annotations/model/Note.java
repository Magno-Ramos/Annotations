package com.appcode.annotations.model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.TypeConverters;
import android.os.Parcel;
import android.os.Parcelable;

@Entity(tableName = "note_table")
@TypeConverters(TagTypeConverter.class)
public class Note extends Item implements Parcelable {

    public String message;

    @ColumnInfo(name = "folder_id")
    private int folderId;

    public Note() {
        super();
        this.message = "";
    }

    protected Note(Parcel in) {
        super(in);
        folderId = in.readInt();
        message = in.readString();
    }

    public static final Creator<Note> CREATOR = new Creator<Note>() {
        @Override
        public Note createFromParcel(Parcel in) {
            return new Note(in);
        }

        @Override
        public Note[] newArray(int size) {
            return new Note[size];
        }
    };

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getFolderId() {
        return folderId;
    }

    public void setFolderId(int folderId) {
        this.folderId = folderId;
    }

    @Override
    public int describeContents() {
        super.describeContents();
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(folderId);
        dest.writeString(message);
    }
}

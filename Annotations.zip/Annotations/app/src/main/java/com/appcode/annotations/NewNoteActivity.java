package com.appcode.annotations;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.appcode.annotations.model.Note;

import java.text.MessageFormat;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import jp.wasabeef.richeditor.RichEditor;

public class NewNoteActivity extends AppCompatActivity {

    public static final int RESULT_UPDATE = 1;
    public static final int RESULT_CREATE = 2;

    public static final String NOTE_INTENT_KEY = "note";

    @BindView(R.id.tv_letter_count)
    TextView tvCountLetter;

    @BindView(R.id.rich_editor)
    RichEditor editor;

    private Note note;

    public static Intent buildUpdateIntent(Context context, Note note) {
        Intent intent = new Intent(context, NewNoteActivity.class);
        intent.putExtra(NOTE_INTENT_KEY, note);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note);

        ButterKnife.bind(this);

        if (getIntent() != null) {
            note = getIntent().getParcelableExtra(NOTE_INTENT_KEY);
            if (note != null) {
                editor.setHtml(note.getMessage());
                tvCountLetter.setText(MessageFormat.format("{0}/999", stripHtml(note.getMessage()).length()));
            }
        }

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(note.getTitle());
        }

        editor.setEditorFontSize(20);
        editor.setPadding(10, 10, 10, 10);
        editor.setPlaceholder(getString(R.string.message));
        editor.setOnTextChangeListener(new RichEditor.OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                note.setMessage(text);
                tvCountLetter.setText(MessageFormat.format("{0}/999", stripHtml(note.getMessage()).length()));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_save, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {

            onBackPressed();
            return true;

        } else if (item.getItemId() == R.id.item_save){

            Intent intent = new Intent();
            intent.putExtra(NOTE_INTENT_KEY, note);
            setResult(RESULT_UPDATE, intent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @OnClick(R.id.bt_bold)
    public void setBold() {
        editor.setBold();
    }

    @OnClick(R.id.bt_italic)
    public void setItalic() {
        editor.setItalic();
    }

    @OnClick(R.id.bt_left)
    public void setLeft() {
        editor.setAlignLeft();
    }

    @OnClick(R.id.bt_center)
    public void setCEnter() {
        editor.setAlignCenter();
    }

    @OnClick(R.id.bt_right)
    public void setRight() {
        editor.setAlignRight();
    }

    private String stripHtml(String html) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
        } else {
            return Html.fromHtml(html).toString();
        }
    }
}

package com.appcode.annotations.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.appcode.annotations.model.Folder;
import com.appcode.annotations.repository.FolderRepository;

import java.util.List;

public class FolderViewModel extends AndroidViewModel {

    private FolderRepository folderRepository;
    private LiveData<List<Folder>> allFolders;

    public FolderViewModel(@NonNull Application application) {
        super(application);

        folderRepository = new FolderRepository(application);
        allFolders = folderRepository.getAllFolders();
    }

    public void insert(Folder folder) {
        folderRepository.insert(folder);
    }

    public void update(Folder folder) {
        folderRepository.update(folder);
    }

    public void delete(Folder folder) {
        folderRepository.delete(folder);
    }

    public LiveData<List<Folder>> getAllFolders() {
        return allFolders;
    }
}
